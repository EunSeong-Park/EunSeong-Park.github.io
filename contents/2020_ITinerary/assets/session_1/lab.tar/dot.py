# skeleton
import math

class Dot:
    def __init__(self, x_input, y_input):
        pass
    def dot_get_x(self):
        # return x (number)
        pass
    def dot_get_y(self):
        # return y (number)
        pass
    def dot_add(self, other):
        # return (x, y) = (x1 + x2, y1 + y2) (Dot)
        pass
    def dot_sub(self, other):
        # return (x, y) = (x1 - x2, y1 - y2) (Dot)
        pass
    def dot_dist_origin(self):
        # return the distance from the origin (0,0) (number)
        pass
    def dot_dist(self, other):
        # return the distance between the two points (number)
        pass
    def dot_midpoint(self, other):
        # return the midpoint between the two points (Dot)
        pass
    def dot_get_line(self, other):
        # return the linear function passes through the two points (string)
        # Ex 1: y = 12x + 5
        # Ex 2: y = 3 (if the line is parallel to x-axis)
        # Ex 3: x = 15 (if the line is parallel to y-axis)
        # Ex 4: Invalid (if the two points are in the same position)
        pass
    def dot_G(self, other1, other2):
        # return the "center of mass" (Dot)
        pass




